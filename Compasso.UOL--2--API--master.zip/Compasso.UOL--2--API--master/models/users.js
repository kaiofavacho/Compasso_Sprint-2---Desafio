const moment = require('moment');
const connection = require('../database/connection');

class User {
//============================================================================================================adicionar método de usuário
    addUser(users, res) {
        //formatting date to brasil pattern
        const birthDate = moment(users.birthDate, 'DD/MM/YYYY').format(
            'YYYY-MM-DD'
        );
//=====================================================================================================================validação de campos

        const birthDateIsValid = moment().diff(birthDate, 'years', false) >= 18;

//====================================================senha forte: entre 6-20 caracteres e pelo menos 1 caractere especial, número e letra
       
        const passwordIsValid = // características invalidas senha
            /^(?=.*[@!#$%^&*()/\\])(?=.*[0-9])(?=.*[a-zA-Z])[@!#$%^&*()/\\a-zA-Z0-9]{6,20}$/.test(
                users.password
            );
        const emailIsValid = // características invalidas email
            /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/gi.test(
                users.email
            );
            
        const cpfIsValid = /[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}\-?[0-9]{2}/.test(
            users.cpf
        );
        const nameIsValid = users.name.length > 2;
        const addressIsValid = users.address.length > 5;
        const numberIsValid = users.number.length > 1;
        const complementIsValid = users.complement.length > 0;
        const cityIsValid = users.city.length > 2;
        const stateIsValid = users.state.length == 2;
        const countryIsValid = users.country.length > 3;
        const zipCodeIsValid = /[0-9]{5}[\d]{3}/.test(users.zipCode);

        const validation = [
            {
                title: 'birthDate',
                isValid: birthDateIsValid,
                message: 'O usuário deve ter pelo menos 18 anos',
            },
            {
                title: 'Password',
                isValid: passwordIsValid,
                message:
                    'Sua senha deve ter: 6 caracteres e no mínimo: um caractere especial, um número, uma maiúscula e uma minúscula',
            },
            {
                title: 'Email',
                isValid: emailIsValid,
                message: 'email inválido, tente outro',
            },
            {
                title: 'CPF',
                isValid: cpfIsValid,
                message: 'CPF inválido, tente outro',
            },
            {
                title: 'name',
                isValid: nameIsValid,
                message: 'Seu nome deve ter pelo menos 3 caracteres',
            },
            {
                title: 'address',
                isValid: addressIsValid,
                message: 'Muito curto. O endereço deve ter pelo menos 6 caracteres',
            },
            {
                title: 'number',
                isValid: numberIsValid,
                message: 'Número curto, tente outro',
            },
            {
                title: 'Complement',
                isValid: complementIsValid,
                message: 'Este campo está vazio',
            },
            {
                title: 'City',
                isValid: cityIsValid,
                message: 'O nome da cidade é muito curto',
            },
            {
                title: 'State',
                isValid: stateIsValid,
                message: 'Estado inválido. Use apenas siglas',
            },
            {
                title: 'Country',
                isValid: countryIsValid,
                message: 'O nome do país é muito curto',
            },
            {
                title: 'Zipcode',
                isValid: zipCodeIsValid,
                message: 'CEP inválido, tente outro',
            },
        ];
 //pegar apenas campos incorretos
        const errors = validation.filter((field) => !field.isValid);
        const errorsExist = errors.length;

        if (errorsExist) {
            res.status(404).json(errors);
        } else {
            const birthdayDate = { ...users, birthDate };
            const sql = `INSERT INTO Users SET ?`;

            connection.query(sql, birthdayDate, (err, results) => {
                if (err) {
                    res.status(404).json(err);
                } else {
                    res.status(201).json(results);
                }
            });
        }
    }
//fim do método de adicionar usuário

//método de lista de usuários
    listUser(res) {
        const sql = 'SELECT * FROM Users';

        connection.query(sql, (err, results) => {
            if (err) {
                res.status(404).json(err);
            } else {
                res.status(200).json(results);
            }
        });
    }
//método de usuário de fim de lista

//listar usuário por método de ID
    listById(id, res) {
        const sql = `SELECT * FROM Users WHERE id=${id}`;

        connection.query(sql, (err, results) => {
            const user = results[0];
            if (err) {
                console.log('mensagem de erro');
                res.status(400).json(err);
            } else {
                res.status(200).json(user);
            }
        });
            //Usuário de fim de lista por método de ID
    }
//usuário final da lista por método de ID

//métodos de atualização
//PATCH
    updateUserPatch(id, values, res) {
        if (values.birthDate) {
            values.birthDate = moment(values.birthDate, 'DD/MM/YYYY').format(
                'YYYY-MM-DD'
            );
        }
        const sql = 'UPDATE Users SET ? WHERE id=?';

        connection.query(sql, [values, id], (err, results) => {
            if (err) {
                res.status(404).json(err);
            } else {
                res.status(201).json(results);
            }
        });
    }

    updateUserPut(id, values, res) {
        if (values.birthDate) {
            values.birthDate = moment(values.birthDate, 'DD/MM/YYYY').format(
                'YYYY-MM-DD'
            );
        }

        const sql = 'UPDATE Users SET ? WHERE id=?';

        connection.query(sql, [values, id], (err, results) => {
            if (err) {
                res.status(404).json(err);
            } else {
                res.status(201).json({ ...values, id });
            }
        });

//métodos de fim de atualizações
    }

//método de exclusão
    deleteUser(id, res) {
        const sql = 'DELETE FROM Users WHERE id=?';

        connection.query(sql, id, (err, results) => {
            if (err) {
                res.status(404).json(err);
            } else {
                res.status(202).json(
                    `User ${id} has been successfully deleted`
                );
            }
        });

        //fim do método de exclusão
    }
}

module.exports = new User();
